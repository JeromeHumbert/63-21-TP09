import java.util.Random;

public class Magasin {

    private static final double TVA = 0.077;

    public static void chargerData(String path){

    }

    public static void ajouterPanier(Instrument i, int quantite){

    }

    public static Instrument selectionRandom(){

    }

    public static void affichagePanier(){

    }

    private static double calculPrix(){

    }

    public static void main(String[] args) {
        int nbAchatsTest = 5;
        int quantiteTestMax = 10;
        String localDir = System.getProperty("user.dir");
        if(System.getProperty("os.name").contains("Windows")){
            chargerData(localDir + "\\src\\instruments.csv");
        }else{
            chargerData(localDir + "/src/instruments.csv");
        }
        Employe e = new Employe(1231,"Tom", "Wunsch");
        Client c = new Client(999, "Maestro45");
        Random r = new Random();
        for(int i = 0; i < nbAchatsTest; i++){
            int quantite = r.nextInt(quantiteTestMax)+1;
            ajouterPanier(selectionRandom(),quantite);
        }
        affichagePanier();
        System.out.println();
        selectionRandom().categorieDetails(c);
        System.out.println();
        selectionRandom().categorieDetails(e);
    }

}
