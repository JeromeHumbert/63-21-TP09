public class Employe {
    private int id;
    private String prenom;
    private String nom;

    public Employe(int id, String prenom, String nom) {
        this.id = id;
        this.prenom = prenom;
        this.nom = nom;
    }

    public String toString(){
        return prenom + " " + nom;
    }
}
