public class Client {
    private int id;
    private String pseudo;

    public Client(int id, String pseudo) {
        this.id = id;
        this.pseudo = pseudo;
    }

    public String toString(){
        return pseudo;
    }
}
